from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Button, Label
import urllib.request

class DoraGramApp(App):
    def build(self):
        self.layout = BoxLayout(orientation='vertical', padding=20, spacing=20)
        self.label = Label(text='DoraGram: Ожидание связи с сервером...', font_size=18)
        self.layout.add_widget(self.label)
        
        btn = Button(text='Проверить связь с VPS', size_hint=(1, 0.3), font_size=18)
        btn.bind(on_press=self.check_server)
        self.layout.add_widget(btn)
        return self.layout

    def check_server(self, instance):
        try:
            url = "http://177.3.221.40/"
            req = urllib.request.urlopen(url, timeout=5)
            self.label.text = f"Статус сервера: Подключено! ({req.getcode()})"
        except Exception as e:
            self.label.text = f"Ошибка связи с сервером: {e}"

if __name__ == '__main__':
    DoraGramApp().run()
