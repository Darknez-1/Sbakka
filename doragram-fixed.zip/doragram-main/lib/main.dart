import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Показываем интерфейс сразу: ошибка или медленный запуск Supabase
  // больше не должны оставлять приложение на чёрном экране.
  runApp(const DoragramApp());
}

class DoragramApp extends StatelessWidget {
  const DoragramApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DoraGram',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFDB4DFF),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF101018),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF171722),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        useMaterial3: true,
      ),
      home: const ChatScreen(),
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  String _backendStatus = 'Подключаем сервер…';
  bool _backendReady = false;
  bool _checkingBackend = true;

  @override
  void initState() {
    super.initState();
    _initializeBackend();
  }

  Future<void> _initializeBackend() async {
    try {
      await Supabase.initialize(
        url: 'https://akdqvlkprebdogpvjpan.supabase.co',
        anonKey: 'sb_publishable_Opygu8s9jJHVala5BNgOlA_HRjtXC1Z',
      );
      if (!mounted) return;
      setState(() {
        _backendReady = true;
        _checkingBackend = false;
        _backendStatus = 'Сервер подключён';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _backendReady = false;
        _checkingBackend = false;
        _backendStatus = 'Сервер недоступен. Интерфейс работает автономно.';
      });
      debugPrint('DoraGram Supabase initialization failed: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _checkingBackend
        ? Colors.amber
        : (_backendReady ? Colors.greenAccent : Colors.orangeAccent);

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.forum_rounded, color: Color(0xFFDB4DFF)),
            SizedBox(width: 10),
            Text('DoraGram'),
          ],
        ),
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 88,
                  height: 88,
                  decoration: BoxDecoration(
                    color: const Color(0xFFDB4DFF).withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(26),
                  ),
                  child: const Icon(
                    Icons.forum_rounded,
                    size: 46,
                    color: Color(0xFFDB4DFF),
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  'Добро пожаловать в DoraGram!',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Твой мессенджер начинается здесь.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, fontSize: 15),
                ),
                const SizedBox(height: 28),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A27),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Row(
                    children: [
                      if (_checkingBackend)
                        const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      else
                        Icon(
                          _backendReady
                              ? Icons.check_circle_rounded
                              : Icons.cloud_off_rounded,
                          color: statusColor,
                          size: 22,
                        ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _backendStatus,
                          style: TextStyle(color: statusColor, fontSize: 14),
                        ),
                      ),
                    ],
                  ),
                ),
                if (!_checkingBackend && !_backendReady) ...[
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: () {
                      setState(() {
                        _checkingBackend = true;
                        _backendStatus = 'Повторное подключение…';
                      });
                      _initializeBackend();
                    },
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Повторить подключение'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
